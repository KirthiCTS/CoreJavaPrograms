package day9javaprograms;

public interface TestInterface {

	
	void testEnumInterface();
}
